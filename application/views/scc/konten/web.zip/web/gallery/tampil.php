  <!--================Hero Banner SM Area Start =================-->
  <section class="hero-banner-sm-404 magic-ball magic-ball-banner" id="parallax-1" data-anchor-target="#parallax-1"
    data-300-top="background-position: 0px -80px" data-top-bottom="background-position: 0 100px">
    <div class="container">
      <div class="hero-banner-sm-content">
        <h1>&nbsp</h1>
        <p class="mb-5">&nbsp</p>
      </div>
    </div>
  </section>
  <h1 class="text-center mb-5 mt-5">Not Found</h1>